from typing import Dict, Any

def serialize_message(sender: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    return {"sender": sender, "payload": payload}

def deserialize_message(message: Dict[str, Any]) -> Dict[str, Any]:
    return message.get("payload", {})
