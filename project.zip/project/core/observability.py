import time
from typing import Dict, Any

class Observability:
    def __init__(self):
        self.logs = []

    def log(self, message: str, meta: Dict[str, Any]=None):
        entry = {"ts": time.time(), "message": message, "meta": meta or {}}
        self.logs.append(entry)

    def get_logs(self):
        return self.logs
