from typing import Dict, Any

def build_context(memory: Dict[str, Any], user_input: str) -> Dict[str, Any]:
    """
    Builds a context object for agents using memory and current input.
    """
    context = {
        "user_input": user_input,
        "user_profile": memory.get("profile", {})
    }
    return context
